<?php
// Script to connect tto the data base
$servername = "localhost";
$username = "root";
$password = "";
$database = "sportsclub";

$conn = mysqli_connect($servername,$username,$password,$database);
?>