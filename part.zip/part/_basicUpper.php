<?php
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<script src="https://code.jquery.com/jquery-3.4.1.js "></script>   

<link rel="stylesheet" href="/gujratsports/css/bootstrap.min.css">
<link rel="stylesheet" href="/gujratsports/fontawesome/css/all.css">
 <!-- <link rel="stylesheet" href="/gujratsports/css/style.css">    -->
 <link rel="stylesheet" href="/gujratsports/css/style.css">
 <style type="text/css">
 body {
     overflow-y: scroll;
     position: relative;
     margin: 0;
     padding: 0;
     background-color: #fff;
     /* background: ;  */
 }
 </style>
</head>
<body>

<?php 
$file1 = 'C:xampp\htdocs\gujratSports\part\_nav.php';
include($file1);

$file3 = 'C:xampp\htdocs\gujratSports\part\_dbconnect.php';
 include ($file3); 
?>
