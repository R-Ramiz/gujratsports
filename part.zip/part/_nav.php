<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/nav.css">
    <!-- <script src="https://kit.fontawesome.com/a076d05399.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.4.1.js "></script>
    
<style>
  body {
    overflow-y: auto;
    position: relative;
}
  </style> 
</head>
  <body>
    <nav><label class="logo">Gujrat Sports</label>
      <ul>
<li><a class="" href="home.php">Dashbord</a></li>
<li><a href="memberlist.php">Member</i></a></li>
<li><a href="Payment.php">Payment</i></a></li>
<li><a href="Attendance.php">Attendance</i></a></li>
<li><a href="Stafflist.php">Staff</i></a></li>
<li><a href="_handlelogout.php">Logout</a></li>
</ul>
</nav>
</body>
</html>

